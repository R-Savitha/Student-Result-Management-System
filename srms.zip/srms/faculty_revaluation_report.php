<html>
    <head>
        <style>
    table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

</style>

</head>

           <center><h1> Re-Evaluation Reports</h1></center>
<table>

<tr></tr>
<tr></tr>
<tr>
    <th> Roll No</th>
    <th> Class</th>
    <th> Subject</th>
    <th> Reason</th>
</tr>

<?php
session_start();
include('includes/config.php');
if($_SESSION['password']==6)
{
$sql = "SELECT * from revaluation where class=6";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<tr>
<td><?php echo htmlentities($result->Roll); ?></td>
<td><?php echo htmlentities($result->class); ?></td>
<td><?php echo htmlentities($result->subject); ?></td>
<td><?php echo htmlentities($result->reason);?>&nbsp;</td>
</tr>
<?php }} ?>
<tr></tr>
<tr></tr>
<tr></tr>
</table>
<?php } ?>
<?php 
if($_SESSION['password']==7)
{
$sql = "SELECT * from revaluation where class=7";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<tr>
<td><?php echo htmlentities($result->Roll); ?></td>
<td><?php echo htmlentities($result->class); ?></td>
<td><?php echo htmlentities($result->subject); ?></td>
<td><?php echo htmlentities($result->reason);?>&nbsp;</td>
</tr>
<?php }} ?>
<tr></tr>
<tr></tr>
<tr></tr>
</table>
<?php } ?>
<?php 
if($_SESSION['password']==8)
{
$sql = "SELECT * from revaluation where class=8";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<tr>
<td><?php echo htmlentities($result->Roll); ?></td>
<td><?php echo htmlentities($result->class); ?></td>
<td><?php echo htmlentities($result->subject); ?></td>
<td><?php echo htmlentities($result->reason);?>&nbsp;</td>
</tr>
<?php }} ?>
<tr></tr>
<tr></tr>
<tr></tr>
</table>
<?php } ?>

<?php 
if($_SESSION['password']==9)
{
$sql = "SELECT * from revaluation where class=9";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   ?>
<tr>
<td><?php echo htmlentities($result->Roll); ?></td>
<td><?php echo htmlentities($result->class); ?></td>
<td><?php echo htmlentities($result->subject); ?></td>
<td><?php echo htmlentities($result->reason);?>&nbsp;</td>
</tr>
<?php }} ?>
<tr></tr>
<tr></tr>
<tr></tr>
</table>
<?php } ?>


<center><a href="dashboard.php">Back to Home</a></center> 


    </html>