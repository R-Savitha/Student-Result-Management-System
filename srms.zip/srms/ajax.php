<?php 
include('includes/config.php');


if(isset($_POST['class_id'])){
	$rollid = $_POST['class_id'];
	$sql = "SELECT tblsubjectcombination.ClassId, tblsubjectcombination.SubjectId, tblsubjects.id, tblsubjects.SubjectName FROM tblsubjectcombination 
		JOIN tblsubjects ON tblsubjects.id = tblsubjectcombination.SubjectId 
		WHERE tblsubjectcombination.ClassId = :rollid";
	$query = $dbh->prepare($sql);
	$query->bindParam(':rollid', $rollid, PDO::PARAM_STR);
	$query->execute();
	$results = $query->fetchAll(PDO::FETCH_OBJ);
	
	echo json_encode($results);
	exit;
}


 ?>